﻿INSERT INTO [dbo].[usuarios_admin] ([nombre], [contraseña]) VALUES (N'admin               ', N'password            ')
INSERT INTO [dbo].[usuarios_admin] ([nombre], [contraseña]) VALUES (N'admin1              ', N'psswrd              ')
