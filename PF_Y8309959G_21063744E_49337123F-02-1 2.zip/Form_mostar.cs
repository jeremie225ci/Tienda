﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace PF_2106
{
    public partial class Form_mostar : Form
    {
        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();

        public Form_mostar()
        {
            InitializeComponent();
            listView1.View = View.Details;
        }

        public void selecionar_listview(int contador)
        {
            if (contador == 0)
            {
                listView1.Columns.Add("Nombre", 40);
                listView1.Columns.Add("Articulos", 200);
                listView1.Columns.Add("Precio", 40);

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM carta;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetDecimal(2).ToString());
                }

                conexion.Close();
                midatareader.Close();
            }
            else if (contador == 1)
            {

                listView1.Columns.Add("ID", 40);
                listView1.Columns.Add("Articulos", 200);
                listView1.Columns.Add("Precio", 40);
                listView1.Columns.Add("Fecha", 40);
                listView1.Columns.Add("Cliente", 40);

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Historico;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetInt32(0).ToString());
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetDecimal(2).ToString());
                    lista.SubItems.Add(midatareader.GetDateTime(3).ToString());
                    lista.SubItems.Add(midatareader.GetString(4));
                }

                conexion.Close();
                midatareader.Close();
            }
            else if (contador == 2)
            {
                listView1.Columns.Add("Nombre", 40);
                listView1.Columns.Add("Categoria", 200);
                listView1.Columns.Add("Cantidad", 40);
                listView1.Columns.Add("Precio", 40);

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos WHERE categoria='algodon';";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetInt32(2).ToString());
                    lista.SubItems.Add(midatareader.GetDecimal(3).ToString());
                }

                conexion.Close();
                midatareader.Close();

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos WHERE categoria='byc';";

                midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetInt32(2).ToString());
                    lista.SubItems.Add(midatareader.GetDecimal(3).ToString());
                }

                conexion.Close();
                midatareader.Close();

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos WHERE categoria='fs';";

                midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetInt32(2).ToString());
                    lista.SubItems.Add(midatareader.GetDecimal(3).ToString());
                }

                conexion.Close();
                midatareader.Close();

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos WHERE categoria='caramelos';";

                midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetInt32(2).ToString());
                    lista.SubItems.Add(midatareader.GetDecimal(3).ToString());
                }

                conexion.Close();
                midatareader.Close();

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos WHERE categoria='chicles';";

                midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetInt32(2).ToString());
                    lista.SubItems.Add(midatareader.GetDecimal(3).ToString());
                }

                conexion.Close();
                midatareader.Close();

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos WHERE categoria='galletas';";

                midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                    lista.SubItems.Add(midatareader.GetInt32(2).ToString());
                    lista.SubItems.Add(midatareader.GetDecimal(3).ToString());
                }

                conexion.Close();
                midatareader.Close();
            }
            else if(contador == 3)
            {
                listView1.Columns.Add("Nombre", 40);
                listView1.Columns.Add("Contraseña", 40);
                
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM usuarios;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                }

                conexion.Close();
                midatareader.Close();
            }
            else if(contador == 4)
            {

                listView1.Columns.Add("Nombre", 40);
                listView1.Columns.Add("Contraseña", 40);

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM usuarios_admin;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    ListViewItem lista;
                    lista = listView1.Items.Add(midatareader.GetString(0));
                    lista.SubItems.Add(midatareader.GetString(1));
                }

                conexion.Close();
                midatareader.Close();
            }
        }

        private void button_salir_Click(object sender, EventArgs e)
        {
            listView1.Columns.Clear();
            listView1.Items.Clear();
            DialogResult = DialogResult.Cancel;
        }
    }
}
