﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PF_2106
{
    public partial class Form_autentificacion : Form
    {
        public Form_autentificacion()
        {
            InitializeComponent();
        }

        public string nombre
        {
            get
            {
                return textBox_nombre.Text;
            }
        }
        public string contraseña
        {
            get
            {
                return textBox_contraseña.Text;
            }
        }

        private void button_confirmar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void button_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
