﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace PF_2106
{
    public partial class Form_añadir_producto : Form
    {
        public Form_añadir_producto()
        {
            InitializeComponent();
        }

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();

        public int detectar_checks(bool carta)
        {

            if((radioButton1.Checked == Enabled)&&(carta == true))
            {
                label3.Visible = false;
                label4.Visible = false;

                label7.Visible = true;
                richTextBox1.Visible = true;
                textBox_precio.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label2.Visible = true;
                textBox_nombre.Visible = true;

                textBox_categoria.Visible = false;
                textBox_cantidad.Visible = false;
              
                return 1;
            }
            else if(radioButton2.Checked == Enabled)
            {
                textBox_nombre.Text = "";
                textBox_categoria.Text = "algodon";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                textBox_nombre.Visible = true;
                textBox_categoria.Visible = true;
                textBox_cantidad.Visible = true;
                textBox_precio.Visible = true;

                label7.Visible = false;
                richTextBox1.Visible = false;

                return 2;

            }
            else if (radioButton3.Checked == Enabled)
            {
                textBox_nombre.Text = "";
                textBox_categoria.Text = "byc";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                textBox_nombre.Visible = true;
                textBox_categoria.Visible = true;
                textBox_cantidad.Visible = true;
                textBox_precio.Visible = true;

                label7.Visible = false;
                richTextBox1.Visible = false;

                return 2;
            }
            else if (radioButton4.Checked == Enabled)
            {
                textBox_nombre.Text = "";
                textBox_categoria.Text = "chicles";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                textBox_nombre.Visible = true;
                textBox_categoria.Visible = true;
                textBox_cantidad.Visible = true;
                textBox_precio.Visible = true;

                label7.Visible = false;
                richTextBox1.Visible = false;

                return 2;
            }
            else if (radioButton5.Checked == Enabled)
            {
                textBox_nombre.Text = "";
                textBox_categoria.Text = "caramelos";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                textBox_nombre.Visible = true;
                textBox_categoria.Visible = true;
                textBox_cantidad.Visible = true;
                textBox_precio.Visible = true;

                label7.Visible = false;
                richTextBox1.Visible = false;

                return 2;
            }
            else if (radioButton6.Checked == Enabled)
            {
                textBox_nombre.Text = "";
                textBox_categoria.Text = "fs";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                textBox_nombre.Visible = true;
                textBox_categoria.Visible = true;
                textBox_cantidad.Visible = true;
                textBox_precio.Visible = true;

                label7.Visible = false;
                richTextBox1.Visible = false;

                return 2;
            }
            else if (radioButton7.Checked == Enabled)
            {
                textBox_nombre.Text = "";
                textBox_categoria.Text = "galletas";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                textBox_nombre.Visible = true;
                textBox_categoria.Visible = true;
                textBox_cantidad.Visible = true;
                textBox_precio.Visible = true;

                label7.Visible = false;
                richTextBox1.Visible = false;

                return 2;
            }
            else
            {
                label7.Visible = false;
                richTextBox1.Visible = false;
                textBox_precio.Visible = false;

                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;

                textBox_nombre.Visible = false;
                textBox_categoria.Visible = false;
                textBox_cantidad.Visible = false;

                textBox_nombre.Text = "";
                textBox_categoria.Text = "";
                textBox_cantidad.Text = "";
                textBox_precio.Text = "";

                return 0;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(true);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(false);
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(false);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(false);
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(false);
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(false);
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            detectar_checks(false);
        }

        private void button_aceptar_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked == Enabled)
            {
                if (((textBox_nombre.Text == "") && (richTextBox1.Text == "") && (textBox_precio.Text == "")) || ((textBox_nombre.Text == "") || (richTextBox1.Text == "") || (textBox_precio.Text == "")))
                {
                    MessageBox.Show("Introduzca los datos correctamente");
                }
                else
                {
                    conexion.Open();
                    comandosql.Connection = conexion;
                    comandosql.CommandText = "SELECT * FROM Carta;";

                    SqlDataReader midatareader = comandosql.ExecuteReader();

                    int comprobar = 0;

                    while (midatareader.Read())
                    {
                        if ((textBox_nombre.Text.Trim() == midatareader.GetString(0).Trim()) && (textBox_categoria.Text == midatareader.GetString(1).Trim()))
                        {
                            comprobar = 1;
                            break;
                        }
                    }

                    conexion.Close();
                    midatareader.Close();

                    if (comprobar == 0)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;

                        comandosql.CommandText = "INSERT INTO Carta VALUES (@nombre, @articulos, @precio)";
                        comandosql.Parameters.AddWithValue("@nombre", textBox_nombre.Text.Trim());
                        comandosql.Parameters.AddWithValue("@articulos", richTextBox1.Text.Trim());
                        comandosql.Parameters.AddWithValue("@precio", decimal.Parse(textBox_precio.Text.Trim()));

                        try
                        {
                            comandosql.ExecuteNonQuery();
                            mitransaccion.Commit();
                            MessageBox.Show("Datos introducidos CORRECTAMENTE");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al conectar con la BBDD");
                        }
                        finally
                        {
                            conexion.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error, ya existe un articulo con ese nombre");

                        textBox_nombre.Text = "";
                        textBox_cantidad.Text = "";
                        textBox_precio.Text = "";
                    }
                }
            }
            else
            {
                if (((textBox_nombre.Text == "") && (textBox_categoria.Text == "") && (textBox_cantidad.Text == "") && (textBox_precio.Text == "")) || ((textBox_nombre.Text == "") || (textBox_categoria.Text == "") || (textBox_cantidad.Text == "") || (textBox_precio.Text == "")))
                {
                    MessageBox.Show("Introduzca los datos correctamente");
                }
                else
                {
                    conexion.Open();
                    comandosql.Connection = conexion;
                    comandosql.CommandText = "SELECT * FROM Productos;";

                    SqlDataReader midatareader = comandosql.ExecuteReader();

                    int comprobar = 0;

                    while (midatareader.Read())
                    {
                        if ((textBox_nombre.Text.Trim() == midatareader.GetString(0).Trim()) && (textBox_categoria.Text == midatareader.GetString(1).Trim()))
                        {
                            comprobar = 1;
                            break;
                        }
                    }

                    conexion.Close();
                    midatareader.Close();

                    if(comprobar == 0)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;

                        comandosql.CommandText = "INSERT INTO Productos VALUES (@nombre, @categoria,~@cantidad, @precio)";
                        comandosql.Parameters.AddWithValue("@nombre", textBox_nombre.Text.Trim());
                        comandosql.Parameters.AddWithValue("@categoria", textBox_categoria.Text.Trim());
                        comandosql.Parameters.AddWithValue("@cantidad", int.Parse(textBox_cantidad.Text.Trim()));
                        comandosql.Parameters.AddWithValue("@precio", decimal.Parse(textBox_precio.Text.Trim()));

                        try
                        {
                            comandosql.ExecuteNonQuery();
                            mitransaccion.Commit();
                            MessageBox.Show("Datos introducidos CORRECTAMENTE");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al conectar con la BBDD");
                        }
                        finally
                        {
                            conexion.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error, ya existe un articulo con ese nombre");

                        textBox_nombre.Text = "";
                        textBox_cantidad.Text = "";
                        textBox_precio.Text = "";
                    }
                }
            }
        }

        private void button_salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
