﻿CREATE TABLE [dbo].[Carta]
(
	[Nombre] NCHAR(20) NOT NULL PRIMARY KEY, 
    [Articulos] NCHAR(80) NOT NULL, 
    [Precio] DECIMAL(18, 2) NOT NULL
)
