﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;        //Usar directiva para SQL

namespace PF_2106
{
    public partial class Form_registrarse : Form
    {
        public Form_registrarse()
        {
            InitializeComponent();
            radioButton_usuario.Checked = true;
        }

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();   //Para el uso de diferentes botones se recomienda crear una variable global

        public bool check_admin
        {
            get
            {
                return radioButton_admin.Checked;
            }
                
        }

        public string nombre
        {
            get
            {
                return textBox1.Text;
            }
        }

        public string contraseña
        {
            get
            {
                return textBox2.Text;
            }
        }

        private void button_aceptar_Click(object sender, EventArgs e)
        {
            if(((textBox1.Text == "") && (textBox2.Text == "")) || ((textBox1.Text == "")||(textBox2.Text == "")))
            {
                MessageBox.Show("Introduzca todos los datos del formulario");
            }
            else
            {
                Form_inicio comprobar = new Form_inicio();

                if(radioButton_admin.Checked == true)
                {
                    Form_inicio comprobar_admin = new Form_inicio();

                    if(comprobar_admin.detectar_admin(textBox1.Text, textBox2.Text, false) == true)
                    {
                        
                        MessageBox.Show("No se pudo asignar el nombre, introduzca otro");

                    }
                    else if (comprobar_admin.detectar_usuario(textBox1.Text, textBox2.Text, false) == true)
                    {
                        MessageBox.Show("No se pudo asignar el nombre, introduzca otro");
                    }
                    else
                    {
                        Form_autentificacion autentificador = new Form_autentificacion();

                        this.Visible = false;

                        if(autentificador.ShowDialog() == DialogResult.OK)
                        {
                            SqlTransaction mitransaccion;       //Crea una transaccion

                            conexion.Open();        //Abre la conexion con la BBDD

                            mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                            comandosql.Connection = conexion;
                            comandosql.Transaction = mitransaccion;
                            comandosql.CommandText = "INSERT INTO usuarios_admin VALUES ('" + textBox1.Text + "','" + textBox2.Text + "');";       //Inroduce el comando

                            try
                            {
                                comandosql.ExecuteNonQuery();   //Ejecuta
                                mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit
                                
                                MessageBox.Show("Administrador registrado con exito");
                                DialogResult = DialogResult.OK;
                            }
                            catch
                            {
                                mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                                MessageBox.Show("Error al introducir los datos a la BBDD");
                            }
                        }
                    }
                }
                else
                {
                    Form_inicio comprobar_usuario = new Form_inicio();

                    if (comprobar_usuario.detectar_admin(textBox1.Text, textBox2.Text, false) == true)
                    {
                        MessageBox.Show("Ya existe un usuario con ese nombre");
                    }
                    else if (comprobar_usuario.detectar_usuario(textBox1.Text, textBox2.Text, false) == true)
                    {
                        MessageBox.Show("Ya existe un usuario con ese nombre");
                    }
                    else
                    {

                       SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "INSERT INTO usuarios VALUES ('" + textBox1.Text + "','" + textBox2.Text + "');";       //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit
                            
                            MessageBox.Show("Usuario resgistrado con exito");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al introducir los datos a la BBDD");
                        }
                    }
                }
            }
        }

        private void button_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
