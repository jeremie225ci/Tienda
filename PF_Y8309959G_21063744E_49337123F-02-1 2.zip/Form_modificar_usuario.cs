﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Data.SqlClient;

namespace PF_2106
{
    public partial class Form_modificar_usuario : Form
    {

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();   

        public Form_modificar_usuario()
        {
            InitializeComponent();
        }

        private void button_aceptar_Click(object sender, EventArgs e)
        {
            if(((textBox_nombre.Text == "")&&(textBox_modificador.Text == ""))||((textBox_nombre.Text == "")||(textBox_modificador.Text == "")))
            {
                MessageBox.Show("Introduzca los datos correctamente");
            }
            else
            {
                if (radioButton1.Checked == Enabled)
                {
                    conexion.Open();
                    comandosql.Connection = conexion;
                    comandosql.CommandText = "Select * FROM usuarios_admin";

                    SqlDataReader midatareader = comandosql.ExecuteReader();

                    int contador = 0;

                    while (midatareader.Read())
                    {
                        if (textBox_nombre.Text == midatareader.GetString(0).Trim())
                        {
                            contador = 1;
                            break;
                        }
                    }

                    midatareader.Close();
                    conexion.Close();

                    conexion.Open();
                    comandosql.Connection = conexion;
                    comandosql.CommandText = "Select * FROM usuarios";

                    midatareader = comandosql.ExecuteReader();

                    while (midatareader.Read())
                    {
                        if (textBox_nombre.Text == midatareader.GetString(0).Trim())
                        {
                            contador = 2;
                            break;
                        }
                    }

                    midatareader.Close();
                    conexion.Close();

                    if (contador == 1)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "UPDATE usuarios_admin SET nombre='" + textBox_modificador.Text + "' WHERE nombre='" + textBox_nombre.Text + "'";  //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                            MessageBox.Show("Nombre actualizado con exito");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback(); //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al modificar los datos a la BBDD");
                        }

                        conexion.Close();
                    }
                    else if (contador == 2)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "UPDATE usuarios SET nombre='" + textBox_modificador.Text + "' WHERE nombre='" + textBox_nombre.Text + "'";  //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                            MessageBox.Show("Nombre actualizado con exito");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback(); //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al modificar los datos a la BBDD");
                        }

                        conexion.Close();
                    }
                    else
                    {
                        MessageBox.Show("El nombre introducido no existe");
                    }
                }
                else if (radioButton2.Checked == Enabled)
                {
                    conexion.Open();
                    comandosql.Connection = conexion;
                    comandosql.CommandText = "Select * FROM usuarios_admin";

                    SqlDataReader midatareader = comandosql.ExecuteReader();

                    int contador = 0;

                    while (midatareader.Read())
                    {
                        if (textBox_nombre.Text == midatareader.GetString(0).Trim())
                        {
                            contador = 1;
                            break;
                        }
                    }

                    midatareader.Close();
                    conexion.Close();

                    conexion.Open();
                    comandosql.Connection = conexion;
                    comandosql.CommandText = "Select * FROM usuarios";

                    midatareader = comandosql.ExecuteReader();

                    while (midatareader.Read())
                    {
                        if (textBox_nombre.Text == midatareader.GetString(0).Trim())
                        {
                            contador = 2;
                            break;
                        }
                    }

                    midatareader.Close();
                    conexion.Close();

                    if (contador == 1)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "UPDATE usuarios_admin SET contraseña='" + textBox_modificador.Text + "' WHERE nombre='" + textBox_nombre.Text + "'";  //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                            MessageBox.Show("Contraseña actualizada con exito");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback(); //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al modificar los datos a la BBDD");
                        }

                        conexion.Close();
                    }
                    else if (contador == 2)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "UPDATE usuarios SET contraseña='" + textBox_modificador.Text + "' WHERE nombre='" + textBox_nombre.Text + "'";  //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                            MessageBox.Show("Contraseña actualizada con exito");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            mitransaccion.Rollback(); //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al modificar los datos a la BBDD");
                        }

                        conexion.Close();
                    }
                    else
                    {
                        MessageBox.Show("El nombre introducido no existe");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca la opcion que desea cambiar");
                }
            }
        }

        private void button_borrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
