﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

using Excel = Microsoft.Office.Interop.Excel;       //Declaraciones para utilizar EXCEL
using System.Reflection;

namespace PF_2106
{
    public partial class Form_tienda_usuario : Form
    {

        Excel.Application objExcel = new Excel.Application();

        private string v_nombre_usuario;

        public string nombre_usuario
        {
            get
            {
                return v_nombre_usuario;
            }
            set
            {
                v_nombre_usuario = value;
            }
        }

        public string label
        {
            set
            {
                label5.Text += " " + value;
                nombre_usuario = value;
            }
        }

        decimal v_precio_total = 0.00m;
        public decimal precio_total
        {
            get
            {
                return v_precio_total;
            }
            set
            {
                v_precio_total = value;
            }
        }

        public Form_tienda_usuario()
        {
            InitializeComponent();
            label1.Font = new Font(label1.Font, FontStyle.Underline);

            opcion_carta(false, 0);

            //BLOQUE1
            label4.Visible = false;
            label6.Visible = false;
            label13.Visible = false;
            domainUpDown1.Visible = false;
            button1.Visible = false;
            domainUpDown1.Text = 1.ToString();

            //BLOQUE2
            label7.Visible = false;
            label12.Visible = false;
            label14.Visible = false;
            domainUpDown2.Visible = false;
            button2.Visible = false;
            domainUpDown2.Text = 1.ToString();
            //BLOQUE3
            label8.Visible = false;
            label9.Visible = false;
            label15.Visible = false;
            domainUpDown3.Visible = false;
            button3.Visible = false;
            domainUpDown3.Text = 1.ToString();
            //BLOQUE4
            label10.Visible = false;
            label11.Visible = false;
            label16.Visible = false;
            domainUpDown4.Visible = false;
            button4.Visible = false;
            domainUpDown4.Text = 1.ToString();
            //BLOQUE5
            label28.Visible = false;
            label24.Visible = false;
            label20.Visible = false;
            domainUpDown5.Visible = false;
            button5.Visible = false;
            domainUpDown5.Text = 1.ToString();
            //BLOQUE6
            label27.Visible = false;
            label21.Visible = false;
            label19.Visible = false;
            domainUpDown6.Visible = false;
            button6.Visible = false;
            domainUpDown6.Text = 1.ToString();
            //BLOQUE7
            label26.Visible = false;
            label23.Visible = false;
            label18.Visible = false;
            domainUpDown7.Visible = false;
            button8.Visible = false;
            domainUpDown7.Text = 1.ToString();
            //BLOQUE8
            label25.Visible = false;
            label22.Visible = false;
            label17.Visible = false;
            domainUpDown8.Visible = false;
            button9.Visible = false;
            domainUpDown8.Text = 1.ToString();
            //BLOQUE9
            label38.Visible = false;
            label35.Visible = false;
            label30.Visible = false;
            domainUpDown9.Visible = false;
            button10.Visible = false;
            domainUpDown9.Text = 1.ToString();
            //BLOQUE10
            label37.Visible = false;
            label34.Visible = false;
            label29.Visible = false;
            domainUpDown10.Visible = false;
            button11.Visible = false;
            domainUpDown10.Text = 1.ToString();
        }

        Form_carrito carrito = new Form_carrito();

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();   //Para el uso de diferentes botones se recomienda crear una variable global

        private void button1_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            label1.Visible = false;

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='algodon';";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                if (midatareader.GetString(1).Trim() == "algodon")
                {
                    contador++;
                }
            }
            activar_etiquetas(contador);

            midatareader.Close();
            conexion.Close();

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='algodon';";

            midatareader = comandosql.ExecuteReader();

            string nombre;
            int cantidad;
            decimal precio;

            int contador2 = 0;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                cantidad = midatareader.GetInt32(2);
                precio = midatareader.GetDecimal(3);

                nombrar_etiquetas(nombre, cantidad, precio, contador, contador2);
                contador2++;
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button_byc_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            label1.Visible = false;

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='byc';";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                contador++;
            }
            activar_etiquetas(contador);

            midatareader.Close();
            conexion.Close();

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='byc';";

            midatareader = comandosql.ExecuteReader();

            string nombre;
            int cantidad;
            decimal precio;

            int contador2 = 0;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                cantidad = midatareader.GetInt32(2);
                precio = midatareader.GetDecimal(3);

                nombrar_etiquetas(nombre, cantidad, precio, contador, contador2);
                contador2++;
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button_chicles_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            label1.Visible = false;

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='chicles';";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                contador++;
            }
            activar_etiquetas(contador);

            midatareader.Close();
            conexion.Close();

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='chicles';";

            midatareader = comandosql.ExecuteReader();

            string nombre;
            int cantidad;
            decimal precio;

            int contador2 = 0;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                cantidad = midatareader.GetInt32(2);
                precio = midatareader.GetDecimal(3);

                nombrar_etiquetas(nombre, cantidad, precio, contador, contador2);
                contador2++;
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button_caramelos_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            label1.Visible = false;

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='caramelos';";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                contador++;
            }
            activar_etiquetas(contador);

            midatareader.Close();
            conexion.Close();

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='caramelos';";

            midatareader = comandosql.ExecuteReader();

            string nombre;
            int cantidad;
            decimal precio;

            int contador2 = 0;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                cantidad = midatareader.GetInt32(2);
                precio = midatareader.GetDecimal(3);

                nombrar_etiquetas(nombre, cantidad, precio, contador, contador2);
                contador2++;
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button_fs_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            label1.Visible = false;

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='fs';";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                contador++;
            }
            activar_etiquetas(contador);


            midatareader.Close();
            conexion.Close();

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='fs';";

            midatareader = comandosql.ExecuteReader();

            string nombre;
            int cantidad;
            decimal precio;

            int contador2 = 0;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                cantidad = midatareader.GetInt32(2);
                precio = midatareader.GetDecimal(3);

                nombrar_etiquetas(nombre, cantidad, precio, contador, contador2);
                contador2++;
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button_galletas_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            label1.Visible = false;

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='galletas';";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                contador++;
            }
            activar_etiquetas(contador);

            midatareader.Close();
            conexion.Close();

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM PRODUCTOS WHERE categoria='galletas';";

            midatareader = comandosql.ExecuteReader();

            string nombre;
            int cantidad;
            decimal precio;

            int contador2 = 0;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                cantidad = midatareader.GetInt32(2);
                precio = midatareader.GetDecimal(3);

                nombrar_etiquetas(nombre, cantidad, precio, contador, contador2);
                contador2++;
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            activar_etiquetas(0);

            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "SELECT * FROM Carta;";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            int contador = 0;

            while (midatareader.Read())
            {
                contador++;

                if (contador == 1)
                {
                    label2.Text = midatareader.GetString(0);
                    label36.Text = "Precio: " + midatareader.GetDecimal(2).ToString() + "€";
                    label41.Text = "Contiene: " + midatareader.GetString(1) + ".";
                }
                if (contador == 2)
                {
                    label32.Text = midatareader.GetString(0);
                    label39.Text = "Precio: " + midatareader.GetDecimal(2).ToString() + "€";
                    label42.Text = "Contiene: " + midatareader.GetString(1) + ".";
                }
                if (contador == 3)
                {
                    label33.Text = midatareader.GetString(0);
                    label40.Text = "Precio: " + midatareader.GetDecimal(2).ToString() + "€";
                    label43.Text = "Contiene: " + midatareader.GetString(1) + ".";
                }
            }

            opcion_carta(true, contador);

            conexion.Close();
            midatareader.Close();
        }

        private void pictureBox_carta_Click(object sender, EventArgs e)
        {
            button7_Click(sender, e);
        }

        private void pictureBox_algodon_Click(object sender, EventArgs e)
        {
            button1_Click(sender, e);
        }

        private void pictureBox_byc_Click(object sender, EventArgs e)
        {
            button_byc_Click(sender, e);
        }

        private void pictureBox_chicles_Click(object sender, EventArgs e)
        {
            button_chicles_Click(sender, e);
        }

        private void pictureBox_caramelos_Click(object sender, EventArgs e)
        {
            button_caramelos_Click(sender, e);
        }

        private void pictureBox_fs_Click(object sender, EventArgs e)
        {
            button_fs_Click(sender, e);
        }

        private void pictureBox_galletas_Click(object sender, EventArgs e)
        {
            button_galletas_Click(sender, e);
        }

        public void activar_etiquetas(int contador)
        {
            switch (contador)
            {
                case 0:
                    //BLOQUE1
                    label4.Visible = false;
                    label6.Visible = false;
                    label13.Visible = false;
                    domainUpDown1.Visible = false;
                    button1.Visible = false;
                    domainUpDown1.Value = 1;

                    //BLOQUE2
                    label7.Visible = false;
                    label12.Visible = false;
                    label14.Visible = false;
                    domainUpDown2.Visible = false;
                    button2.Visible = false;
                    domainUpDown2.Value = 1;
                    //BLOQUE3
                    label8.Visible = false;
                    label9.Visible = false;
                    label15.Visible = false;
                    domainUpDown3.Visible = false;
                    button3.Visible = false;
                    domainUpDown3.Value = 1;
                    //BLOQUE4
                    label10.Visible = false;
                    label11.Visible = false;
                    label16.Visible = false;
                    domainUpDown4.Visible = false;
                    button4.Visible = false;
                    domainUpDown4.Value = 1;
                    //BLOQUE5
                    label28.Visible = false;
                    label24.Visible = false;
                    label20.Visible = false;
                    domainUpDown5.Visible = false;
                    button5.Visible = false;
                    domainUpDown5.Value = 1;
                    //BLOQUE6
                    label27.Visible = false;
                    label21.Visible = false;
                    label19.Visible = false;
                    domainUpDown6.Visible = false;
                    button6.Visible = false;
                    domainUpDown6.Value = 1;
                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 1:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    //BLOQUE2
                    label7.Visible = false;
                    label12.Visible = false;
                    label14.Visible = false;
                    domainUpDown2.Visible = false;
                    button2.Visible = false;
                    domainUpDown2.Value = 1;
                    //BLOQUE3
                    label8.Visible = false;
                    label9.Visible = false;
                    label15.Visible = false;
                    domainUpDown3.Visible = false;
                    button3.Visible = false;
                    domainUpDown3.Value = 1;
                    //BLOQUE4
                    label10.Visible = false;
                    label11.Visible = false;
                    label16.Visible = false;
                    domainUpDown4.Visible = false;
                    button4.Visible = false;
                    domainUpDown4.Value = 1;
                    //BLOQUE5
                    label28.Visible = false;
                    label24.Visible = false;
                    label20.Visible = false;
                    domainUpDown5.Visible = false;
                    button5.Visible = false;
                    domainUpDown5.Value = 1;
                    //BLOQUE6
                    label27.Visible = false;
                    label21.Visible = false;
                    label19.Visible = false;
                    domainUpDown6.Visible = false;
                    button6.Visible = false;
                    domainUpDown6.Value = 1;
                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 2:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    //BLOQUE3
                    label8.Visible = false;
                    label9.Visible = false;
                    label15.Visible = false;
                    domainUpDown3.Visible = false;
                    button3.Visible = false;
                    domainUpDown3.Value = 1;
                    //BLOQUE4
                    label10.Visible = false;
                    label11.Visible = false;
                    label16.Visible = false;
                    domainUpDown4.Visible = false;
                    button4.Visible = false;
                    domainUpDown4.Value = 1;
                    //BLOQUE5
                    label28.Visible = false;
                    label24.Visible = false;
                    label20.Visible = false;
                    domainUpDown5.Visible = false;
                    button5.Visible = false;
                    domainUpDown5.Value = 1;
                    //BLOQUE6
                    label27.Visible = false;
                    label21.Visible = false;
                    label19.Visible = false;
                    domainUpDown6.Visible = false;
                    button6.Visible = false;
                    domainUpDown6.Value = 1;
                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 3:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    //BLOQUE4
                    label10.Visible = false;
                    label11.Visible = false;
                    label16.Visible = false;
                    domainUpDown4.Visible = false;
                    button4.Visible = false;
                    domainUpDown4.Value = 1;
                    //BLOQUE5
                    label28.Visible = false;
                    label24.Visible = false;
                    label20.Visible = false;
                    domainUpDown5.Visible = false;
                    button5.Visible = false;
                    domainUpDown5.Value = 1;
                    //BLOQUE6
                    label27.Visible = false;
                    label21.Visible = false;
                    label19.Visible = false;
                    domainUpDown6.Visible = false;
                    button6.Visible = false;
                    domainUpDown6.Value = 1;
                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 4:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;


                    //BLOQUE5
                    label28.Visible = false;
                    label24.Visible = false;
                    label20.Visible = false;
                    domainUpDown5.Visible = false;
                    button5.Visible = false;
                    domainUpDown5.Value = 1;
                    //BLOQUE6
                    label27.Visible = false;
                    label21.Visible = false;
                    label19.Visible = false;
                    domainUpDown6.Visible = false;
                    button6.Visible = false;
                    domainUpDown6.Value = 1;
                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 5:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;

                    label28.Visible = true;
                    label24.Visible = true;
                    label20.Visible = true;
                    domainUpDown5.Visible = true;
                    button5.Visible = true;
                    domainUpDown5.Value = 1;


                    //BLOQUE6
                    label27.Visible = false;
                    label21.Visible = false;
                    label19.Visible = false;
                    domainUpDown6.Visible = false;
                    button6.Visible = false;
                    domainUpDown6.Value = 1;
                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 6:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;

                    label28.Visible = true;
                    label24.Visible = true;
                    label20.Visible = true;
                    domainUpDown5.Visible = true;
                    button5.Visible = true;
                    domainUpDown5.Value = 1;

                    label27.Visible = true;
                    label21.Visible = true;
                    label19.Visible = true;
                    domainUpDown6.Visible = true;
                    button6.Visible = true;
                    domainUpDown6.Value = 1;


                    //BLOQUE7
                    label26.Visible = false;
                    label23.Visible = false;
                    label18.Visible = false;
                    domainUpDown7.Visible = false;
                    button8.Visible = false;
                    domainUpDown7.Value = 1;
                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 7:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;

                    label28.Visible = true;
                    label24.Visible = true;
                    label20.Visible = true;
                    domainUpDown5.Visible = true;
                    button5.Visible = true;
                    domainUpDown5.Value = 1;

                    label27.Visible = true;
                    label21.Visible = true;
                    label19.Visible = true;
                    domainUpDown6.Visible = true;
                    button6.Visible = true;
                    domainUpDown6.Value = 1;

                    label26.Visible = true;
                    label23.Visible = true;
                    label18.Visible = true;
                    domainUpDown7.Visible = true;
                    button8.Visible = true;
                    domainUpDown7.Value = 1;


                    //BLOQUE8
                    label25.Visible = false;
                    label22.Visible = false;
                    label17.Visible = false;
                    domainUpDown8.Visible = false;
                    button9.Visible = false;
                    domainUpDown8.Value = 1;
                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 8:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;

                    label28.Visible = true;
                    label24.Visible = true;
                    label20.Visible = true;
                    domainUpDown5.Visible = true;
                    button5.Visible = true;
                    domainUpDown5.Value = 1;

                    label27.Visible = true;
                    label21.Visible = true;
                    label19.Visible = true;
                    domainUpDown6.Visible = true;
                    button6.Visible = true;
                    domainUpDown6.Value = 1;

                    label26.Visible = true;
                    label23.Visible = true;
                    label18.Visible = true;
                    domainUpDown7.Visible = true;
                    button8.Visible = true;
                    domainUpDown7.Value = 1;

                    label25.Visible = true;
                    label22.Visible = true;
                    label17.Visible = true;
                    domainUpDown8.Visible = true;
                    button9.Visible = true;
                    domainUpDown8.Value = 1;


                    //BLOQUE9
                    label38.Visible = false;
                    label35.Visible = false;
                    label30.Visible = false;
                    domainUpDown9.Visible = false;
                    button10.Visible = false;
                    domainUpDown9.Value = 1;
                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 9:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;

                    label28.Visible = true;
                    label24.Visible = true;
                    label20.Visible = true;
                    domainUpDown5.Visible = true;
                    button5.Visible = true;
                    domainUpDown5.Value = 1;

                    label27.Visible = true;
                    label21.Visible = true;
                    label19.Visible = true;
                    domainUpDown6.Visible = true;
                    button6.Visible = true;
                    domainUpDown6.Value = 1;

                    label26.Visible = true;
                    label23.Visible = true;
                    label18.Visible = true;
                    domainUpDown7.Visible = true;
                    button8.Visible = true;
                    domainUpDown7.Value = 1;

                    label25.Visible = true;
                    label22.Visible = true;
                    label17.Visible = true;
                    domainUpDown8.Visible = true;
                    button9.Visible = true;
                    domainUpDown8.Value = 1;

                    label38.Visible = true;
                    label35.Visible = true;
                    label30.Visible = true;
                    domainUpDown9.Visible = true;
                    button10.Visible = true;
                    domainUpDown9.Value = 1;

                    //BLOQUE10
                    label37.Visible = false;
                    label34.Visible = false;
                    label29.Visible = false;
                    domainUpDown10.Visible = false;
                    button11.Visible = false;
                    domainUpDown10.Value = 1;
                    break;
                case 10:
                    label4.Visible = true;
                    label6.Visible = true;
                    label13.Visible = true;
                    domainUpDown1.Visible = true;
                    button1.Visible = true;
                    domainUpDown1.Value = 1;

                    label7.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    domainUpDown2.Visible = true;
                    button2.Visible = true;
                    domainUpDown2.Value = 1;

                    label8.Visible = true;
                    label9.Visible = true;
                    label15.Visible = true;
                    domainUpDown3.Visible = true;
                    button3.Visible = true;
                    domainUpDown3.Value = 1;

                    label10.Visible = true;
                    label11.Visible = true;
                    label16.Visible = true;
                    domainUpDown4.Visible = true;
                    button4.Visible = true;
                    domainUpDown4.Value = 1;

                    label28.Visible = true;
                    label24.Visible = true;
                    label20.Visible = true;
                    domainUpDown5.Visible = true;
                    button5.Visible = true;
                    domainUpDown5.Value = 1;

                    label27.Visible = true;
                    label21.Visible = true;
                    label19.Visible = true;
                    domainUpDown6.Visible = true;
                    button6.Visible = true;
                    domainUpDown6.Value = 1;

                    label26.Visible = true;
                    label23.Visible = true;
                    label18.Visible = true;
                    domainUpDown7.Visible = true;
                    button8.Visible = true;
                    domainUpDown7.Value = 1;

                    label25.Visible = true;
                    label22.Visible = true;
                    label17.Visible = true;
                    domainUpDown8.Visible = true;
                    button9.Visible = true;
                    domainUpDown8.Value = 1;

                    label38.Visible = true;
                    label35.Visible = true;
                    label30.Visible = true;
                    domainUpDown9.Visible = true;
                    button10.Visible = true;
                    domainUpDown9.Value = 1;

                    label37.Visible = true;
                    label34.Visible = true;
                    label29.Visible = true;
                    domainUpDown10.Visible = true;
                    button11.Visible = true;
                    domainUpDown10.Value = 1;
                    break;
            }
        }

        public void nombrar_etiquetas(string nombre, int cantidad, decimal precio, int contador, int contador2)
        {

            switch (contador)
            {
                case 1:
                    label4.Text = nombre;
                    label6.Text = "Cantidad: " + cantidad.ToString();
                    label13.Text = "Precio: " + precio.ToString() + " €";
                    break;
                case 2:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 > 0)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 3:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 4:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 5:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 4)
                    {
                        label28.Text = nombre;
                        label24.Text = "Cantidad: " + cantidad.ToString();
                        label20.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 6:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 4)
                    {
                        label28.Text = nombre;
                        label24.Text = "Cantidad: " + cantidad.ToString();
                        label20.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 5)
                    {
                        label27.Text = nombre;
                        label21.Text = "Cantidad: " + cantidad.ToString();
                        label19.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 7:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 4)
                    {
                        label28.Text = nombre;
                        label24.Text = "Cantidad: " + cantidad.ToString();
                        label20.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 5)
                    {
                        label27.Text = nombre;
                        label21.Text = "Cantidad: " + cantidad.ToString();
                        label19.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 6)
                    {
                        label26.Text = nombre;
                        label23.Text = "Cantidad: " + cantidad.ToString();
                        label18.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 8:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 4)
                    {
                        label28.Text = nombre;
                        label24.Text = "Cantidad: " + cantidad.ToString();
                        label20.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 5)
                    {
                        label27.Text = nombre;
                        label21.Text = "Cantidad: " + cantidad.ToString();
                        label19.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 6)
                    {
                        label26.Text = nombre;
                        label23.Text = "Cantidad: " + cantidad.ToString();
                        label18.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 7)
                    {
                        label25.Text = nombre;
                        label22.Text = "Cantidad: " + cantidad.ToString(); cantidad.ToString();
                        label17.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 9:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 4)
                    {
                        label28.Text = nombre;
                        label24.Text = "Cantidad: " + cantidad.ToString();
                        label20.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 5)
                    {
                        label27.Text = nombre;
                        label21.Text = "Cantidad: " + cantidad.ToString();
                        label19.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 6)
                    {
                        label26.Text = nombre;
                        label23.Text = "Cantidad: " + cantidad.ToString();
                        label18.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 7)
                    {
                        label25.Text = nombre;
                        label22.Text = "Cantidad: " + cantidad.ToString();
                        label17.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 8)
                    {
                        label38.Text = nombre;
                        label35.Text = "Cantidad: " + cantidad.ToString();
                        label30.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
                case 10:
                    if (contador2 == 0)
                    {
                        label4.Text = nombre;
                        label6.Text = "Cantidad: " + cantidad.ToString();
                        label13.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 1)
                    {
                        label7.Text = nombre;
                        label12.Text = "Cantidad: " + cantidad.ToString();
                        label14.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 2)
                    {
                        label8.Text = nombre;
                        label9.Text = "Cantidad: " + cantidad.ToString();
                        label15.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 3)
                    {
                        label10.Text = nombre;
                        label11.Text = "Cantidad: " + cantidad.ToString();
                        label16.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 4)
                    {
                        label28.Text = nombre;
                        label24.Text = "Cantidad: " + cantidad.ToString();
                        label20.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 5)
                    {
                        label27.Text = nombre;
                        label21.Text = "Cantidad: " + cantidad.ToString();
                        label19.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 6)
                    {
                        label26.Text = nombre;
                        label23.Text = "Cantidad: " + cantidad.ToString();
                        label18.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 7)
                    {
                        label25.Text = nombre;
                        label22.Text = "Cantidad: " + cantidad.ToString();
                        label17.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 8)
                    {
                        label38.Text = nombre;
                        label35.Text = "Cantidad: " + cantidad.ToString();
                        label30.Text = "Precio: " + precio.ToString() + " €";
                    }

                    if (contador2 == 9)
                    {
                        label37.Text = nombre;
                        label34.Text = "Cantidad: " + cantidad.ToString();
                        label29.Text = "Precio: " + precio.ToString() + " €";
                    }
                    break;
            }
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            if (domainUpDown1.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label4.Text)
                    {
                        v_precio_total += precio * domainUpDown1.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label4.Text);
                        milista_carrito.SubItems.Add(domainUpDown1.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown1.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (domainUpDown2.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label7.Text)
                    {
                        v_precio_total += precio * domainUpDown2.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label7.Text);
                        milista_carrito.SubItems.Add(domainUpDown2.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown2.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (domainUpDown3.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label8.Text)
                    {
                        v_precio_total += precio * domainUpDown3.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label8.Text);
                        milista_carrito.SubItems.Add(domainUpDown3.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown3.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (domainUpDown4.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label10.Text)
                    {
                        v_precio_total += precio * domainUpDown4.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label10.Text);
                        milista_carrito.SubItems.Add(domainUpDown4.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown4.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (domainUpDown5.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label28.Text)
                    {
                        v_precio_total += precio * domainUpDown5.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label28.Text);
                        milista_carrito.SubItems.Add(domainUpDown5.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown5.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (domainUpDown6.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label27.Text)
                    {
                        v_precio_total += precio * domainUpDown6.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label27.Text);
                        milista_carrito.SubItems.Add(domainUpDown6.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown6.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (domainUpDown7.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label26.Text)
                    {
                        v_precio_total += precio * domainUpDown7.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label26.Text);
                        milista_carrito.SubItems.Add(domainUpDown7.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown7.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (domainUpDown8.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label25.Text)
                    {
                        v_precio_total += precio * domainUpDown8.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label25.Text);
                        milista_carrito.SubItems.Add(domainUpDown8.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown8.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (domainUpDown9.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label38.Text)
                    {
                        v_precio_total += precio * domainUpDown9.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label38.Text);
                        milista_carrito.SubItems.Add(domainUpDown9.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown9.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (domainUpDown10.Value > 0)
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM Productos;";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                string nombre;
                decimal precio;

                while (midatareader.Read())
                {
                    nombre = midatareader.GetString(0).Trim();
                    precio = midatareader.GetDecimal(3);

                    if (nombre == label37.Text)
                    {
                        v_precio_total += precio * domainUpDown10.Value;

                        ListViewItem milista_carrito;

                        milista_carrito = carrito.lista.Items.Add(label37.Text);
                        milista_carrito.SubItems.Add(domainUpDown10.Value.ToString());
                        milista_carrito.SubItems.Add((precio * domainUpDown10.Value).ToString());

                        label31.Text = "Precio: " + v_precio_total + "€";
                    }
                }

                midatareader.Close();
                conexion.Close();
            }
            else
            {
                MessageBox.Show("Se debe de añadir por lo menos 1 unidad para comprar");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            opcion_carta(false, 0);
            carrito.p_total_carrito = v_precio_total;

            carrito.label = "Precio total: " + carrito.p_total_carrito + "€";

            carrito.nombre = v_nombre_usuario;

            if (carrito.ShowDialog() == DialogResult.OK)
            {

                MessageBox.Show("Pago realizado con exito, creando factura");

                objExcel.Visible = false;

                Excel.Workbook objLibro = objExcel.Workbooks.Add(Missing.Value);        //Creamos el libro y nos dirigimos a la primera hoja
                Excel.Worksheet objHoja = (Excel.Worksheet)objLibro.Worksheets.get_Item(1);

                objHoja.Cells[1, 1] = "Nombre";
                objHoja.Cells[1, 2] = "Cantidad";
                objHoja.Cells[1, 3] = "Precio";

                int j = 2;
                foreach (ListViewItem item in carrito.lista.Items)
                {
                    objHoja.Cells[j, 1] = item.SubItems[0].Text;
                    objHoja.Cells[j, 2] = item.SubItems[1].Text;
                    objHoja.Cells[j, 3] = item.SubItems[2].Text;

                    j++;
                }

                objHoja.Cells[j, 4] = "Total: " + carrito.p_total_carrito.ToString() + "€";
                objExcel.Visible = true;

                int i = 0;

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "SELECT id FROM Historico";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    i = midatareader.GetInt32(0);
                }

                i++;

                midatareader.Close();

                SqlTransaction mitransaccion;       //Crea una transaccion
                mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                comandosql.Connection = conexion;
                comandosql.Transaction = mitransaccion;

                string articulos = "";

                foreach (ListViewItem item in carrito.lista.Items)
                {
                    articulos += " ,x" + item.SubItems[1].Text + " " + item.SubItems[0].Text;
                }

                articulos += ".";

                comandosql.CommandText = "INSERT INTO Historico VALUES (@i, @articulos, @precio, @fecha_actual, @cliente)";
                comandosql.Parameters.AddWithValue("@i", i);
                comandosql.Parameters.AddWithValue("@articulos", articulos);
                comandosql.Parameters.AddWithValue("@precio", carrito.p_total_carrito);
                comandosql.Parameters.AddWithValue("@fecha_actual", DateTime.Now.Date);
                comandosql.Parameters.AddWithValue("@cliente", v_nombre_usuario);

                try
                {
                    comandosql.ExecuteNonQuery();
                    mitransaccion.Commit();
                    carrito.lista.Items.Clear();
                    v_precio_total = 0.00m;
                    label31.Text = "Precio: " + v_precio_total + "€";
                }
                catch
                {
                    mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                    MessageBox.Show("Error al conectar con la BBDD");
                }

                objExcel.Quit();

                conexion.Close();
            }
            else
            {
                v_precio_total = carrito.p_total_carrito;
                label31.Text = "Precio: " + v_precio_total + "€";
            }
        }

        private void pictureBox_carrito_Click(object sender, EventArgs e)
        {
            button12_Click(sender, e);
        }

        public void opcion_carta(bool escoger, int contador)
        {
            if(escoger == true)
            {

                if(contador == 1)
                {
                    label2.Visible = true;
                    button13.Visible = true;
                    label36.Visible = true;
                    label41.Visible = true;
                }
                if(contador == 2)
                {
                    label2.Visible = true;
                    button13.Visible = true;
                    label36.Visible = true;
                    label41.Visible = true;

                    label32.Visible = true;
                    button14.Visible = true;
                    label39.Visible = true;
                    label42.Visible = true;
                }
                if(contador == 3)
                {
                    label2.Visible = true;
                    button13.Visible = true;
                    label36.Visible = true;
                    label41.Visible = true;

                    label32.Visible = true;
                    button14.Visible = true;
                    label39.Visible = true;
                    label42.Visible = true;

                    label33.Visible = true;
                    button15.Visible = true;
                    label40.Visible = true;
                    label43.Visible = true;
                }
            }
            else
            {
                label2.Visible = false;
                label32.Visible = false;
                label33.Visible = false;
                button13.Visible = false;
                button14.Visible = false;
                button15.Visible = false;
                label36.Visible = false;
                label39.Visible = false;
                label40.Visible = false;
                label41.Visible = false;
                label42.Visible = false;
                label43.Visible = false;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "Select * FROM Carta;";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            string nombre;
            decimal precio;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                precio = midatareader.GetDecimal(2);

                if (nombre.Trim() == label2.Text.Trim())
                {

                    v_precio_total += precio;

                    ListViewItem milista_carrito;

                    milista_carrito = carrito.lista.Items.Add(label2.Text);
                    milista_carrito.SubItems.Add(1.ToString());
                    milista_carrito.SubItems.Add(precio.ToString());

                    label31.Text = "Precio: " + v_precio_total + "€";
                }
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "Select * FROM Carta;";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            string nombre;
            decimal precio;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                precio = midatareader.GetDecimal(2);

                if (nombre.Trim() == label32.Text.Trim())
                {
                    v_precio_total += precio;

                    ListViewItem milista_carrito;

                    milista_carrito = carrito.lista.Items.Add(label32.Text);
                    milista_carrito.SubItems.Add(1.ToString());
                    milista_carrito.SubItems.Add(precio.ToString());

                    label31.Text = "Precio: " + v_precio_total + "€";
                }
            }

            midatareader.Close();
            conexion.Close();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            conexion.Open();
            comandosql.Connection = conexion;
            comandosql.CommandText = "Select * FROM Carta;";

            SqlDataReader midatareader = comandosql.ExecuteReader();

            string nombre;
            decimal precio;

            while (midatareader.Read())
            {
                nombre = midatareader.GetString(0).Trim();
                precio = midatareader.GetDecimal(2);

                MessageBox.Show(nombre + precio.ToString());

                if (nombre.Trim() == label33.Text.Trim())
                {
                    v_precio_total += precio;

                    ListViewItem milista_carrito;

                    milista_carrito = carrito.lista.Items.Add(label33.Text);
                    milista_carrito.SubItems.Add(1.ToString());
                    milista_carrito.SubItems.Add(precio.ToString());

                    label31.Text = "Precio: " + v_precio_total + "€";
                }
            }

            midatareader.Close();
            conexion.Close();
        }
    }
}
