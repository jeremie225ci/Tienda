﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;        //Usar directiva

namespace PF_2106
{
    public partial class Form_contraseña_cambiada : Form
    {
        public Form_contraseña_cambiada()
        {
            InitializeComponent();
        }

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();   //Para el uso de diferentes botones se recomienda crear una variable global

        public string nombre
        {
            get
            {
                return textBox_nombre.Text;
            }
        }

        public string contraseña_antigua
        {
            get
            {
                return textBox_contraseña.Text;
            }
        }

        public string contraseña_nueva
        {
            get
            {
                return textBox_ncontraseña.Text;
            }
        }

        public string contraseña_nueva_confirmar
        {
            get
            {
                return textBox_cncontraseña.Text;
            }
        }

        private void button_cancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_aceptar_Click(object sender, EventArgs e)
        {
            if (((textBox_nombre.Text == "") && (textBox_contraseña.Text == "") && (textBox_ncontraseña.Text == "") && (textBox_cncontraseña.Text == "")) || ((textBox_nombre.Text == "") || (textBox_contraseña.Text == "") || (textBox_ncontraseña.Text == "") || (textBox_cncontraseña.Text == "")))
            {
                MessageBox.Show("Introduzca todos los datos");
            }
            else
            {
                if ((contraseña_nueva == contraseña_nueva_confirmar) && (contraseña_nueva != contraseña_antigua))
                {
                    Form_inicio comprobar = new Form_inicio();

                    if (comprobar.detectar_usuario(textBox_nombre.Text, textBox_contraseña.Text, false) == true)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "UPDATE usuarios SET contraseña='" + textBox_ncontraseña.Text + "' WHERE nombre='" + textBox_nombre.Text + "' AND contraseña='" + textBox_contraseña.Text + "'";  //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                            MessageBox.Show("Contraseña actualizada con EXITO");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al modificar los datos a la BBDD");
                        }

                        conexion.Close();
                    }
                    if (comprobar.detectar_admin(textBox_nombre.Text, textBox_contraseña.Text, false) == true)
                    {
                        SqlTransaction mitransaccion;       //Crea una transaccion

                        conexion.Open();        //Abre la conexion con la BBDD

                        mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                        comandosql.Connection = conexion;
                        comandosql.Transaction = mitransaccion;
                        comandosql.CommandText = "UPDATE usuario_admin SET contraseña='" + textBox_ncontraseña.Text + "' WHERE nombre='" + textBox_nombre.Text + "' AND contraseña='" + textBox_contraseña.Text + "'";  //Inroduce el comando

                        try
                        {
                            comandosql.ExecuteNonQuery();   //Ejecuta
                            mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                            MessageBox.Show("Contraseña actualizada con EXITO");
                            DialogResult = DialogResult.OK;
                        }
                        catch
                        {
                            //Si hay error se eliminará lo realizado
                            MessageBox.Show("Error al modificar los datos a la BBDD");
                        }

                        conexion.Close();
                    }
                }
                else
                {
                    MessageBox.Show("La contraseña no coincide (contraseña_nueva != contraseña_nueva_confirmar) o la contraseña nueva es la misma contraseña que la antigua");
                }
            }
        }
    }
}

