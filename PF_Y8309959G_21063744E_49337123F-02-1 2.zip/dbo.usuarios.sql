﻿CREATE TABLE [dbo].[usuarios] (
    [nombre]     NCHAR (20) NOT NULL,
    [contraseña] NCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([nombre] ASC)
);

