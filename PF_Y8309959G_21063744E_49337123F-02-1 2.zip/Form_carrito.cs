﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace PF_2106
{
    public partial class Form_carrito : Form
    {
        public ListView lista
        {
            get
            {
                return listView1;
            }
            set
            {
                listView1 = value;
            }
        }

        decimal v_p_total_carrito;
        public decimal p_total_carrito
        {
            get
            {
                return v_p_total_carrito;
            }
            set
            {
                v_p_total_carrito = value;
            }
        }

        private string nombre_usuario;
        public string nombre
        {
            set
            {
                nombre_usuario = value;
            }
        }

        public string label
        {
            set
            {
                label2.Text = value;
            }
        }



        public Form_carrito()
        {
            InitializeComponent();
        }

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();   //Para el uso de diferentes botones se recomienda crear una variable global

        private void button_pagar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void button_salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count > 0)
            {
                Form_modificar_cantidad modificar = new Form_modificar_cantidad();

                modificar.label_nombre = listView1.SelectedItems[0].SubItems[0].Text;

                if(modificar.ShowDialog() == DialogResult.OK)
                {
                    foreach (ListViewItem item in listView1.SelectedItems)
                    {
                        if(item.SubItems[0].Text == modificar.label_nombre)
                        {
                            if(modificar.cantidad > 0)
                            {
                                int cantidad_ant;
                                cantidad_ant = int.Parse(item.SubItems[1].Text);
                                item.SubItems[1].Text = modificar.cantidad.ToString();

                                conexion.Open();
                                comandosql.Connection = conexion;
                                comandosql.CommandText = "SELECT * FROM PRODUCTOS;";

                                SqlDataReader midatareader = comandosql.ExecuteReader();

                                decimal precio;

                                while (midatareader.Read())
                                {
                                    if (midatareader.GetString(0).Trim() == modificar.label_nombre.ToString())
                                    {
                                        precio = midatareader.GetDecimal(3);

                                        v_p_total_carrito -= precio * cantidad_ant;
                                        
                                        item.SubItems[2].Text = (precio * modificar.cantidad).ToString();

                                        v_p_total_carrito += precio * modificar.cantidad;

                                        label2.Text = "Precio total: " + v_p_total_carrito + "€";
                                    }
                                }

                                midatareader.Close();
                                conexion.Close();

                            }
                            else
                            {
                                v_p_total_carrito -= decimal.Parse(item.SubItems[2].Text);

                                label2.Text = "Precio total: " + v_p_total_carrito + "€";

                                listView1.Items.Remove(item);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecciona una fila primero para modificar");
            }
        }

        private void button_eliminar_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count > 0)
            {
                decimal precio = decimal.Parse(listView1.SelectedItems[0].SubItems[2].Text);
                v_p_total_carrito -= precio;
                label2.Text = "Precio total: " + v_p_total_carrito + "€";
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
            else
            {
                MessageBox.Show("Seleccione un fila para eliminar");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("¿Estas seguro de eliminar todo el carrito", "Aviso", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                listView1.Items.Clear();

                v_p_total_carrito = 0;

                label2.Text = "Precio total: " + v_p_total_carrito + "€";
            }
        }
    }
}
