﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;        //Usar directiva

namespace PF_2106
{
    public partial class Form_inicio : Form
    {
        public Form_inicio()
        {
            InitializeComponent();
        }

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();   //Para el uso de diferentes botones se recomienda crear una variable global

        //BOTON ENTRAR
        private void button_entrar_Click(object sender, EventArgs e)
        {
            
            if(((textBox_nombre.Text == "")&&(textBox_contraseña.Text == ""))||((textBox_nombre.Text == "")||(textBox_contraseña.Text == "")))
            {
                MessageBox.Show("Debe de introducir los datos");
            }
            else
            {

                if (detectar_usuario(textBox_nombre.Text,textBox_contraseña.Text, true) == true)
                {
                    MessageBox.Show("Inicio de sesion con exito");

                    this.Visible = false;

                    Form_tienda_usuario tienda = new Form_tienda_usuario();

                    tienda.label = textBox_nombre.Text;

                    if (tienda.ShowDialog() == DialogResult.Cancel)
                    {
                        if (MessageBox.Show("Cerrando Sesion") == DialogResult.OK)
                        {
                            textBox_nombre.Text = "";
                            textBox_contraseña.Text = "";
                            this.Visible = true;
                        }

                        
                    }
                
                }
                else if(detectar_admin(textBox_nombre.Text,textBox_contraseña.Text, true) == true)

                {
                    this.Visible = false;

                    Form_admin administrador = new Form_admin();

                    administrador.nombre_usuario = textBox_nombre.Text;

                    if(administrador.ShowDialog() == DialogResult.Cancel)
                    {
                        if (MessageBox.Show("Cerrando Sesion") == DialogResult.OK)
                        {
                            textBox_nombre.Text = "";
                            textBox_contraseña.Text = "";
                            this.Visible = true;
                        }
                    }
                    
                }
                else
                {
                    MessageBox.Show("El usuario o contraseña no existe o son incorrectos");
                }

            }
        }

        //BOTON SALIR
        private void button_salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //REGISTRARSE
        private void label4_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            Form_registrarse registro = new Form_registrarse();

            if (registro.ShowDialog() == DialogResult.OK)
            {
                textBox_nombre.Text = "";
                textBox_contraseña.Text = "";
                this.Visible = true;
            }
            else
            {
                textBox_nombre.Text = "";
                textBox_contraseña.Text = "";
                this.Visible = true;
            }
        }

        //CAMBIAR CONTRASEÑA
        private void label_contraseña_olvidada_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form_contraseña_cambiada contraseña = new Form_contraseña_cambiada();
            
            if (contraseña.ShowDialog() == DialogResult.OK) 
            {
                textBox_nombre.Text = "";
                textBox_contraseña.Text = "";
                this.Visible = true;
            }
            else
            {
                textBox_nombre.Text = "";
                textBox_contraseña.Text = "";
                this.Visible = true;
            }
     
        }

        public bool detectar_admin(string nombre, string contraseña, bool inicio)
        {

            conexion.Open();
            comandosql.Connection = conexion;

            if (inicio == true)
            {
                comandosql.CommandText = "SELECT nombre,contraseña FROM usuarios_admin;";
            }
            else
            {
                comandosql.CommandText = "SELECT nombre FROM usuarios_admin;";
            }

            SqlDataReader midatareader = comandosql.ExecuteReader();

            string nombre_dato;
            string contraseña_dato;

            while (midatareader.Read())
            {
                nombre_dato = midatareader.GetString(0).Trim();

                if(inicio == true)
                {
                    contraseña_dato = midatareader.GetString(1).Trim();
                    if((nombre_dato == nombre)&&(contraseña_dato == contraseña))
                    {
                        midatareader.Close();
                        conexion.Close();
                        return true;
                    }
                }
                else
                {
                    if(nombre_dato == nombre)
                    {
                        midatareader.Close();
                        conexion.Close();
                        return true;
                    }
                }

            }
            midatareader.Close();
            conexion.Close();
            return false;
        }

        public bool detectar_usuario(string nombre, string contraseña, bool inicio)
        {
            conexion.Open();
            comandosql.Connection = conexion;

            if (inicio == true)
            {
                comandosql.CommandText = "SELECT nombre,contraseña FROM usuarios;";
            }
            else
            {
                comandosql.CommandText = "SELECT nombre FROM usuarios;";
            }

            SqlDataReader midatareader = comandosql.ExecuteReader();

            string nombre_dato;
            string contraseña_dato;

            while (midatareader.Read())
            {
                nombre_dato = midatareader.GetString(0).Trim();

                if (inicio == true)
                {
                    contraseña_dato = midatareader.GetString(1).Trim();
                    if ((nombre_dato == nombre) && (contraseña_dato == contraseña))
                    {
                        midatareader.Close();
                        conexion.Close();
                        return true;
                    }
                }
                else
                {
                    if (nombre_dato == nombre)
                    {
                        midatareader.Close();
                        conexion.Close();
                        return true;
                    }
                }

            }

            midatareader.Close();
            conexion.Close();

            return false;
        }
    }
}
