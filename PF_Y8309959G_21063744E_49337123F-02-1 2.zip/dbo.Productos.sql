﻿CREATE TABLE [dbo].[Productos]
(
	[nombre] NCHAR(30) NOT NULL PRIMARY KEY, 
    [categoria] NCHAR(10) NOT NULL, 
    [Cantidad] INT NULL, 
    [Precio] DECIMAL NULL
)
