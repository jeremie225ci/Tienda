﻿
namespace PF_2106
{
    partial class Form_tienda_usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_tienda_usuario));
            this.label3 = new System.Windows.Forms.Label();
            this.button_algodon = new System.Windows.Forms.Button();
            this.button_chicles = new System.Windows.Forms.Button();
            this.button_caramelos = new System.Windows.Forms.Button();
            this.button_fs = new System.Windows.Forms.Button();
            this.button_byc = new System.Windows.Forms.Button();
            this.button_galletas = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox_algodon = new System.Windows.Forms.PictureBox();
            this.pictureBox_byc = new System.Windows.Forms.PictureBox();
            this.pictureBox_chicles = new System.Windows.Forms.PictureBox();
            this.pictureBox_caramelos = new System.Windows.Forms.PictureBox();
            this.pictureBox_fs = new System.Windows.Forms.PictureBox();
            this.pictureBox_galletas = new System.Windows.Forms.PictureBox();
            this.pictureBox_carta = new System.Windows.Forms.PictureBox();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox_carrito = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.domainUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.domainUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.button12 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_algodon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_byc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_chicles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_caramelos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_fs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_galletas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_carta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_carrito)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown10)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(275, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Gasolina peréz";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_algodon
            // 
            this.button_algodon.Image = global::PF_2106.Properties.Resources._16649629834092;
            this.button_algodon.Location = new System.Drawing.Point(4, 124);
            this.button_algodon.Name = "button_algodon";
            this.button_algodon.Size = new System.Drawing.Size(215, 55);
            this.button_algodon.TabIndex = 4;
            this.button_algodon.Text = "Algodon de Azucar";
            this.button_algodon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_algodon.UseVisualStyleBackColor = true;
            this.button_algodon.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_chicles
            // 
            this.button_chicles.Image = global::PF_2106.Properties.Resources._5cfa3b4c173eb1;
            this.button_chicles.Location = new System.Drawing.Point(4, 250);
            this.button_chicles.Name = "button_chicles";
            this.button_chicles.Size = new System.Drawing.Size(215, 60);
            this.button_chicles.TabIndex = 5;
            this.button_chicles.Text = "Chicles";
            this.button_chicles.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_chicles.UseVisualStyleBackColor = true;
            this.button_chicles.Click += new System.EventHandler(this.button_chicles_Click);
            // 
            // button_caramelos
            // 
            this.button_caramelos.ForeColor = System.Drawing.Color.DarkSalmon;
            this.button_caramelos.Image = global::PF_2106.Properties.Resources._0e15f976b38d6eacff74fa4e177187fa;
            this.button_caramelos.Location = new System.Drawing.Point(4, 316);
            this.button_caramelos.Name = "button_caramelos";
            this.button_caramelos.Size = new System.Drawing.Size(215, 59);
            this.button_caramelos.TabIndex = 6;
            this.button_caramelos.Text = "Caramelos";
            this.button_caramelos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_caramelos.UseVisualStyleBackColor = true;
            this.button_caramelos.Click += new System.EventHandler(this.button_caramelos_Click);
            // 
            // button_fs
            // 
            this.button_fs.ForeColor = System.Drawing.Color.Coral;
            this.button_fs.Image = global::PF_2106.Properties.Resources.istockphoto_496689738_612x612;
            this.button_fs.Location = new System.Drawing.Point(4, 381);
            this.button_fs.Name = "button_fs";
            this.button_fs.Size = new System.Drawing.Size(215, 58);
            this.button_fs.TabIndex = 7;
            this.button_fs.Text = "Frutos Secos";
            this.button_fs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_fs.UseVisualStyleBackColor = true;
            this.button_fs.Click += new System.EventHandler(this.button_fs_Click);
            // 
            // button_byc
            // 
            this.button_byc.Image = global::PF_2106.Properties.Resources.como_hacer_bombones_de_chocolate_23544_600;
            this.button_byc.Location = new System.Drawing.Point(4, 185);
            this.button_byc.Name = "button_byc";
            this.button_byc.Size = new System.Drawing.Size(215, 59);
            this.button_byc.TabIndex = 8;
            this.button_byc.Text = "Bombones y Chocolate";
            this.button_byc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_byc.UseVisualStyleBackColor = true;
            this.button_byc.Click += new System.EventHandler(this.button_byc_Click);
            // 
            // button_galletas
            // 
            this.button_galletas.Image = global::PF_2106.Properties.Resources.galletas_de_chocolate_receta_facil;
            this.button_galletas.Location = new System.Drawing.Point(4, 445);
            this.button_galletas.Name = "button_galletas";
            this.button_galletas.Size = new System.Drawing.Size(215, 59);
            this.button_galletas.TabIndex = 9;
            this.button_galletas.Text = "Galletas";
            this.button_galletas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_galletas.UseVisualStyleBackColor = true;
            this.button_galletas.Click += new System.EventHandler(this.button_galletas_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(7, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Bienvenido:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(369, 337);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Seleccione una categoria";
            // 
            // pictureBox_algodon
            // 
            this.pictureBox_algodon.Location = new System.Drawing.Point(160, 135);
            this.pictureBox_algodon.Name = "pictureBox_algodon";
            this.pictureBox_algodon.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_algodon.TabIndex = 14;
            this.pictureBox_algodon.TabStop = false;
            this.pictureBox_algodon.Click += new System.EventHandler(this.pictureBox_algodon_Click);
            // 
            // pictureBox_byc
            // 
            this.pictureBox_byc.Location = new System.Drawing.Point(170, 199);
            this.pictureBox_byc.Name = "pictureBox_byc";
            this.pictureBox_byc.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_byc.TabIndex = 15;
            this.pictureBox_byc.TabStop = false;
            this.pictureBox_byc.Click += new System.EventHandler(this.pictureBox_byc_Click);
            // 
            // pictureBox_chicles
            // 
            this.pictureBox_chicles.Image = global::PF_2106.Properties.Resources._5cfa3b4c173eb;
            this.pictureBox_chicles.Location = new System.Drawing.Point(83, 264);
            this.pictureBox_chicles.Name = "pictureBox_chicles";
            this.pictureBox_chicles.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_chicles.TabIndex = 16;
            this.pictureBox_chicles.TabStop = false;
            this.pictureBox_chicles.Click += new System.EventHandler(this.pictureBox_chicles_Click);
            // 
            // pictureBox_caramelos
            // 
            this.pictureBox_caramelos.Location = new System.Drawing.Point(100, 330);
            this.pictureBox_caramelos.Name = "pictureBox_caramelos";
            this.pictureBox_caramelos.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_caramelos.TabIndex = 17;
            this.pictureBox_caramelos.TabStop = false;
            this.pictureBox_caramelos.Click += new System.EventHandler(this.pictureBox_caramelos_Click);
            // 
            // pictureBox_fs
            // 
            this.pictureBox_fs.Location = new System.Drawing.Point(116, 395);
            this.pictureBox_fs.Name = "pictureBox_fs";
            this.pictureBox_fs.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_fs.TabIndex = 18;
            this.pictureBox_fs.TabStop = false;
            this.pictureBox_fs.Click += new System.EventHandler(this.pictureBox_fs_Click);
            // 
            // pictureBox_galletas
            // 
            this.pictureBox_galletas.Location = new System.Drawing.Point(83, 458);
            this.pictureBox_galletas.Name = "pictureBox_galletas";
            this.pictureBox_galletas.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_galletas.TabIndex = 19;
            this.pictureBox_galletas.TabStop = false;
            this.pictureBox_galletas.Click += new System.EventHandler(this.pictureBox_galletas_Click);
            // 
            // pictureBox_carta
            // 
            this.pictureBox_carta.Location = new System.Drawing.Point(160, 74);
            this.pictureBox_carta.Name = "pictureBox_carta";
            this.pictureBox_carta.Size = new System.Drawing.Size(35, 32);
            this.pictureBox_carta.TabIndex = 22;
            this.pictureBox_carta.TabStop = false;
            this.pictureBox_carta.Click += new System.EventHandler(this.pictureBox_carta_Click);
            // 
            // button7
            // 
            this.button7.Image = global::PF_2106.Properties.Resources._840_560;
            this.button7.Location = new System.Drawing.Point(4, 63);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(215, 55);
            this.button7.TabIndex = 21;
            this.button7.Text = "Carta de Productos";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox_carrito
            // 
            this.pictureBox_carrito.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_carrito.Image")));
            this.pictureBox_carrito.Location = new System.Drawing.Point(28, 537);
            this.pictureBox_carrito.Name = "pictureBox_carrito";
            this.pictureBox_carrito.Size = new System.Drawing.Size(61, 51);
            this.pictureBox_carrito.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_carrito.TabIndex = 23;
            this.pictureBox_carrito.TabStop = false;
            this.pictureBox_carrito.Click += new System.EventHandler(this.pictureBox_carrito_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(251, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 24;
            this.label4.Text = "label4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(502, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "label7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(251, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 16);
            this.label8.TabIndex = 27;
            this.label8.Text = "label8";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(502, 213);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 16);
            this.label10.TabIndex = 29;
            this.label10.Text = "label10";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(252, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "label6";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label9.Location = new System.Drawing.Point(252, 244);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "label9";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label11.Location = new System.Drawing.Point(503, 244);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "label11";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label12.Location = new System.Drawing.Point(503, 106);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(254, 122);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 16);
            this.label13.TabIndex = 34;
            this.label13.Text = "label13";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(505, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 16);
            this.label14.TabIndex = 35;
            this.label14.Text = "label14";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(254, 264);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 16);
            this.label15.TabIndex = 36;
            this.label15.Text = "label15";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(505, 264);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(51, 16);
            this.label16.TabIndex = 37;
            this.label16.Text = "label16";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(508, 519);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 16);
            this.label17.TabIndex = 49;
            this.label17.Text = "label17";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(257, 519);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 16);
            this.label18.TabIndex = 48;
            this.label18.Text = "label18";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(508, 377);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 16);
            this.label19.TabIndex = 47;
            this.label19.Text = "label19";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(257, 377);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 16);
            this.label20.TabIndex = 46;
            this.label20.Text = "label20";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label21.Location = new System.Drawing.Point(506, 361);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 13);
            this.label21.TabIndex = 45;
            this.label21.Text = "label21";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label22.Location = new System.Drawing.Point(506, 499);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 13);
            this.label22.TabIndex = 44;
            this.label22.Text = "label22";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label23.Location = new System.Drawing.Point(255, 499);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 43;
            this.label23.Text = "label23";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label24.Location = new System.Drawing.Point(255, 361);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 13);
            this.label24.TabIndex = 42;
            this.label24.Text = "label24";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(505, 468);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 16);
            this.label25.TabIndex = 41;
            this.label25.Text = "label25";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(254, 468);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(51, 16);
            this.label26.TabIndex = 40;
            this.label26.Text = "label26";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(505, 337);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 16);
            this.label27.TabIndex = 39;
            this.label27.Text = "label27";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(254, 337);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(51, 16);
            this.label28.TabIndex = 38;
            this.label28.Text = "label28";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(508, 676);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(51, 16);
            this.label29.TabIndex = 61;
            this.label29.Text = "label29";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(257, 676);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(51, 16);
            this.label30.TabIndex = 60;
            this.label30.Text = "label30";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label34.Location = new System.Drawing.Point(506, 656);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 13);
            this.label34.TabIndex = 56;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.label35.Location = new System.Drawing.Point(255, 656);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 55;
            this.label35.Text = "label35";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(505, 625);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(51, 16);
            this.label37.TabIndex = 53;
            this.label37.Text = "label37";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(254, 625);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(51, 16);
            this.label38.TabIndex = 52;
            this.label38.Text = "label38";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(295, 145);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 63;
            this.button1.Text = "Comprar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(543, 145);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 65;
            this.button2.Text = "Comprar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(295, 287);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 69;
            this.button3.Text = "Comprar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(543, 287);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 67;
            this.button4.Text = "Comprar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(295, 399);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 73;
            this.button5.Text = "Comprar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(543, 395);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 71;
            this.button6.Text = "Comprar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(295, 547);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 77;
            this.button8.Text = "Comprar";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(543, 546);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 75;
            this.button9.Text = "Comprar";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(295, 696);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 81;
            this.button10.Text = "Comprar";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(543, 696);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 79;
            this.button11.Text = "Comprar";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // domainUpDown1
            // 
            this.domainUpDown1.Location = new System.Drawing.Point(254, 145);
            this.domainUpDown1.Name = "domainUpDown1";
            this.domainUpDown1.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown1.TabIndex = 82;
            // 
            // domainUpDown2
            // 
            this.domainUpDown2.Location = new System.Drawing.Point(502, 145);
            this.domainUpDown2.Name = "domainUpDown2";
            this.domainUpDown2.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown2.TabIndex = 83;
            // 
            // domainUpDown3
            // 
            this.domainUpDown3.Location = new System.Drawing.Point(254, 288);
            this.domainUpDown3.Name = "domainUpDown3";
            this.domainUpDown3.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown3.TabIndex = 84;
            // 
            // domainUpDown4
            // 
            this.domainUpDown4.Location = new System.Drawing.Point(502, 288);
            this.domainUpDown4.Name = "domainUpDown4";
            this.domainUpDown4.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown4.TabIndex = 85;
            // 
            // domainUpDown5
            // 
            this.domainUpDown5.Location = new System.Drawing.Point(255, 400);
            this.domainUpDown5.Name = "domainUpDown5";
            this.domainUpDown5.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown5.TabIndex = 86;
            // 
            // domainUpDown6
            // 
            this.domainUpDown6.Location = new System.Drawing.Point(502, 397);
            this.domainUpDown6.Name = "domainUpDown6";
            this.domainUpDown6.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown6.TabIndex = 87;
            // 
            // domainUpDown7
            // 
            this.domainUpDown7.Location = new System.Drawing.Point(254, 548);
            this.domainUpDown7.Name = "domainUpDown7";
            this.domainUpDown7.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown7.TabIndex = 88;
            // 
            // domainUpDown8
            // 
            this.domainUpDown8.Location = new System.Drawing.Point(502, 548);
            this.domainUpDown8.Name = "domainUpDown8";
            this.domainUpDown8.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown8.TabIndex = 89;
            // 
            // domainUpDown9
            // 
            this.domainUpDown9.Location = new System.Drawing.Point(255, 697);
            this.domainUpDown9.Name = "domainUpDown9";
            this.domainUpDown9.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown9.TabIndex = 90;
            // 
            // domainUpDown10
            // 
            this.domainUpDown10.Location = new System.Drawing.Point(502, 697);
            this.domainUpDown10.Name = "domainUpDown10";
            this.domainUpDown10.Size = new System.Drawing.Size(35, 22);
            this.domainUpDown10.TabIndex = 91;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(22, 594);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 92;
            this.button12.Text = "Carrito";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(19, 620);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(83, 16);
            this.label31.TabIndex = 93;
            this.label31.Text = "Precio: 0.00€";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(252, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 97;
            this.label2.Text = "label2";
            this.label2.Visible = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(252, 236);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(51, 16);
            this.label32.TabIndex = 98;
            this.label32.Text = "label32";
            this.label32.Visible = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(252, 410);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(51, 16);
            this.label33.TabIndex = 99;
            this.label33.Text = "label33";
            this.label33.Visible = false;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(464, 67);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(125, 54);
            this.button13.TabIndex = 100;
            this.button13.Text = "Comprar";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Visible = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(464, 236);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(125, 54);
            this.button14.TabIndex = 101;
            this.button14.Text = "Comprar";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Visible = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(464, 400);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(125, 54);
            this.button15.TabIndex = 102;
            this.button15.Text = "Comprar";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Visible = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(314, 104);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(123, 17);
            this.label36.TabIndex = 0;
            this.label36.Text = "label36";
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(316, 272);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(121, 17);
            this.label39.TabIndex = 103;
            this.label39.Text = "label39";
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(316, 445);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(121, 17);
            this.label40.TabIndex = 104;
            this.label40.Text = "label40";
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(252, 171);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(366, 59);
            this.label41.TabIndex = 105;
            this.label41.Text = "label41";
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(249, 316);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(385, 76);
            this.label42.TabIndex = 106;
            this.label42.Text = "label42";
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(255, 468);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(363, 75);
            this.label43.TabIndex = 107;
            this.label43.Text = "label43";
            // 
            // Form_tienda_usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = global::PF_2106.Properties.Resources.shutterstock_576138706;
            this.ClientSize = new System.Drawing.Size(748, 728);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.domainUpDown10);
            this.Controls.Add(this.domainUpDown9);
            this.Controls.Add(this.domainUpDown8);
            this.Controls.Add(this.domainUpDown7);
            this.Controls.Add(this.domainUpDown6);
            this.Controls.Add(this.domainUpDown5);
            this.Controls.Add(this.domainUpDown4);
            this.Controls.Add(this.domainUpDown3);
            this.Controls.Add(this.domainUpDown2);
            this.Controls.Add(this.domainUpDown1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox_carrito);
            this.Controls.Add(this.pictureBox_carta);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.pictureBox_galletas);
            this.Controls.Add(this.pictureBox_fs);
            this.Controls.Add(this.pictureBox_caramelos);
            this.Controls.Add(this.pictureBox_chicles);
            this.Controls.Add(this.pictureBox_byc);
            this.Controls.Add(this.pictureBox_algodon);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_galletas);
            this.Controls.Add(this.button_byc);
            this.Controls.Add(this.button_fs);
            this.Controls.Add(this.button_caramelos);
            this.Controls.Add(this.button_chicles);
            this.Controls.Add(this.button_algodon);
            this.Controls.Add(this.label3);
            this.Name = "Form_tienda_usuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tienda";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_algodon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_byc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_chicles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_caramelos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_fs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_galletas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_carta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_carrito)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainUpDown10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_algodon;
        private System.Windows.Forms.Button button_chicles;
        private System.Windows.Forms.Button button_caramelos;
        private System.Windows.Forms.Button button_fs;
        private System.Windows.Forms.Button button_byc;
        private System.Windows.Forms.Button button_galletas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox_algodon;
        private System.Windows.Forms.PictureBox pictureBox_byc;
        private System.Windows.Forms.PictureBox pictureBox_chicles;
        private System.Windows.Forms.PictureBox pictureBox_caramelos;
        private System.Windows.Forms.PictureBox pictureBox_fs;
        private System.Windows.Forms.PictureBox pictureBox_galletas;
        private System.Windows.Forms.PictureBox pictureBox_carta;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pictureBox_carrito;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.NumericUpDown domainUpDown1;
        private System.Windows.Forms.NumericUpDown domainUpDown2;
        private System.Windows.Forms.NumericUpDown domainUpDown3;
        private System.Windows.Forms.NumericUpDown domainUpDown4;
        private System.Windows.Forms.NumericUpDown domainUpDown5;
        private System.Windows.Forms.NumericUpDown domainUpDown6;
        private System.Windows.Forms.NumericUpDown domainUpDown7;
        private System.Windows.Forms.NumericUpDown domainUpDown8;
        private System.Windows.Forms.NumericUpDown domainUpDown9;
        private System.Windows.Forms.NumericUpDown domainUpDown10;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
    }
}