﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PF_2106
{
    public partial class Form_admin : Form
    {
        public Form_admin()
        {
            InitializeComponent();
        }

        string v_nombre_usuario;
        public string nombre_usuario
        {
            set
            {
                label2.Text = "Bienvenido: " + value;
                v_nombre_usuario = value;
            }
        }

        private void button_salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_mostar_Click(object sender, EventArgs e)
        {
            Form_mostar mostar =  new Form_mostar();

            try
            {
                if(comboBox1.Text == "Carta")
                {
                    mostar.selecionar_listview(0);
                }
                else if(comboBox1.Text == "Historico")
                {
                    mostar.selecionar_listview(1);
                }
                else if (comboBox1.Text == "Productos")
                {
                    mostar.selecionar_listview(2);
                }
                else if (comboBox1.Text == "Usuarios")
                {
                    mostar.selecionar_listview(3);
                }
                else if (comboBox1.Text == "Usuarios Administradores")
                {
                    mostar.selecionar_listview(4);
                }

                this.Visible = false;

                if(mostar.ShowDialog() == DialogResult.Cancel)
                {
                    this.Visible = true;
                    comboBox1.Text = "";
                }


            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Introduzc una opcion para mostrar");
            }
        }

        private void button_crear_Click(object sender, EventArgs e)
        {
            Form_añadir_producto añadir = new Form_añadir_producto();

            this.Visible = false;

            if(añadir.ShowDialog() == DialogResult.OK)
            {

            }

            this.Visible = true;

        }

        private void button_eliminar_Click(object sender, EventArgs e)
        {
            Form_borrar_producto borrar = new Form_borrar_producto();

            this.Visible = false;

            if(borrar.ShowDialog() == DialogResult.OK)
            {

            }

            this.Visible = true;
        }

        private void button_musuario_Click(object sender, EventArgs e)
        {
            Form_modificar_usuario mu = new Form_modificar_usuario();

            this.Visible = false;

            if(mu.ShowDialog() == DialogResult.OK)
            {

            }

            this.Visible = true;
        }

        private void button_eusuario_Click(object sender, EventArgs e)
        {
            Form_eliminar_usuario eliminar = new Form_eliminar_usuario();

            this.Visible = false;

            if(eliminar.ShowDialog() == DialogResult.OK)
            {

            }

            this.Visible = true;
        }
    }
}
