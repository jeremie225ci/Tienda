﻿INSERT INTO [dbo].[usuarios] ([nombre], [contraseña]) VALUES (N'usuario1            ', N'1234                ')
