﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Data.SqlClient;

namespace PF_2106
{
    public partial class Form_borrar_producto : Form
    {

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();

        public Form_borrar_producto()
        {
            InitializeComponent();
        }

        private void button_aceptar_Click(object sender, EventArgs e)
        {
            if(((textBox_nombre.Text == "")&&(textBox_categoria.Text == "")) || ((textBox_nombre.Text == "") || (textBox_categoria.Text == "")))
            {
                MessageBox.Show("Introduzca los datos correctamente");
            }
            else
            {
                if (textBox_categoria.Text == "Carta")
                {
                    SqlTransaction mitransaccion;       //Crea una transaccion

                    conexion.Open();        //Abre la conexion con la BBDD

                    mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                    comandosql.Connection = conexion;
                    comandosql.Transaction = mitransaccion;

                    comandosql.CommandText = "DELETE FROM Carta WHERE nombre=@nombre";
                    comandosql.Parameters.AddWithValue("@nombre", textBox_nombre.Text.Trim());

                    try
                    {
                        comandosql.ExecuteNonQuery();
                        mitransaccion.Commit();
                        MessageBox.Show("Datos eliminados CORRECTAMENTE");
                        DialogResult = DialogResult.OK;
                    }
                    catch
                    {
                        mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                        MessageBox.Show("Error al conectar con la BBDD");
                    }
                    finally
                    {
                        conexion.Close();
                    }
                }
                else
                {
                    SqlTransaction mitransaccion;       //Crea una transaccion

                    conexion.Open();        //Abre la conexion con la BBDD

                    mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                    comandosql.Connection = conexion;
                    comandosql.Transaction = mitransaccion;

                    comandosql.CommandText = "DELETE FROM Productos WHERE nombre=@nombre AND categoria=@categoria";
                    comandosql.Parameters.AddWithValue("@nombre", textBox_nombre.Text.Trim());
                    comandosql.Parameters.AddWithValue("@categoria", textBox_categoria.Text.Trim());

                    try
                    {
                        comandosql.ExecuteNonQuery();
                        mitransaccion.Commit();
                        MessageBox.Show("Datos eliminados CORRECTAMENTE");
                        DialogResult = DialogResult.OK;
                    }
                    catch
                    {
                        mitransaccion.Rollback();       //Si hay error se eliminará lo realizado
                        MessageBox.Show("Error al conectar con la BBDD");
                    }
                    finally
                    {
                        conexion.Close();
                    }
                }
            }
        }

        private void button_salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
