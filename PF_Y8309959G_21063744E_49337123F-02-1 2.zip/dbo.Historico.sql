﻿CREATE TABLE [dbo].[Historico] (
    [Id]        INT         NOT NULL,
    [Articulos] NCHAR(200) NOT NULL,
    [Precio]    DECIMAL(18, 2)  NOT NULL,
    [Fecha]     DATE        NOT NULL,
    [Cliente]   NCHAR(20)  NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

