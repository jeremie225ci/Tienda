﻿
namespace PF_2106
{
    partial class Form_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button_mostar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button_crear = new System.Windows.Forms.Button();
            this.button_eliminar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button_eusuario = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button_musuario = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button_salir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mostrar:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Carta",
            "Historico",
            "Productos",
            "Usuarios",
            "Usuarios Administradores"});
            this.comboBox1.Location = new System.Drawing.Point(12, 95);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 1;
            // 
            // button_mostar
            // 
            this.button_mostar.Location = new System.Drawing.Point(271, 89);
            this.button_mostar.Name = "button_mostar";
            this.button_mostar.Size = new System.Drawing.Size(75, 23);
            this.button_mostar.TabIndex = 2;
            this.button_mostar.Text = "Mostar";
            this.button_mostar.UseVisualStyleBackColor = true;
            this.button_mostar.Click += new System.EventHandler(this.button_mostar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Crear producto";
            // 
            // button_crear
            // 
            this.button_crear.Location = new System.Drawing.Point(274, 152);
            this.button_crear.Name = "button_crear";
            this.button_crear.Size = new System.Drawing.Size(75, 23);
            this.button_crear.TabIndex = 7;
            this.button_crear.Text = "Crear";
            this.button_crear.UseVisualStyleBackColor = true;
            this.button_crear.Click += new System.EventHandler(this.button_crear_Click);
            // 
            // button_eliminar
            // 
            this.button_eliminar.Location = new System.Drawing.Point(274, 204);
            this.button_eliminar.Name = "button_eliminar";
            this.button_eliminar.Size = new System.Drawing.Size(75, 23);
            this.button_eliminar.TabIndex = 9;
            this.button_eliminar.Text = "Eliminar";
            this.button_eliminar.UseVisualStyleBackColor = true;
            this.button_eliminar.Click += new System.EventHandler(this.button_eliminar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Eliminar producto";
            // 
            // button_eusuario
            // 
            this.button_eusuario.Location = new System.Drawing.Point(276, 324);
            this.button_eusuario.Name = "button_eusuario";
            this.button_eusuario.Size = new System.Drawing.Size(75, 23);
            this.button_eusuario.TabIndex = 13;
            this.button_eusuario.Text = "Eliminar";
            this.button_eusuario.UseVisualStyleBackColor = true;
            this.button_eusuario.Click += new System.EventHandler(this.button_eusuario_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 327);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Eliminar usuario";
            // 
            // button_musuario
            // 
            this.button_musuario.Location = new System.Drawing.Point(276, 272);
            this.button_musuario.Name = "button_musuario";
            this.button_musuario.Size = new System.Drawing.Size(75, 23);
            this.button_musuario.TabIndex = 11;
            this.button_musuario.Text = "Modificar";
            this.button_musuario.UseVisualStyleBackColor = true;
            this.button_musuario.Click += new System.EventHandler(this.button_musuario_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Modificar usuario";
            // 
            // button_salir
            // 
            this.button_salir.Location = new System.Drawing.Point(278, 12);
            this.button_salir.Name = "button_salir";
            this.button_salir.Size = new System.Drawing.Size(75, 23);
            this.button_salir.TabIndex = 14;
            this.button_salir.Text = "Salir";
            this.button_salir.UseVisualStyleBackColor = true;
            this.button_salir.Click += new System.EventHandler(this.button_salir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "label2";
            // 
            // Form_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PF_2106.Properties.Resources.estadistica_descriptiva_e_inferencial;
            this.ClientSize = new System.Drawing.Size(365, 358);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_salir);
            this.Controls.Add(this.button_eusuario);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_musuario);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_eliminar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_crear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_mostar);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administrador";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button_mostar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_crear;
        private System.Windows.Forms.Button button_eliminar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_eusuario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button_musuario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_salir;
        private System.Windows.Forms.Label label2;
    }
}