﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace PF_2106
{
    public partial class Form_eliminar_usuario : Form
    {

        SqlConnection conexion = new SqlConnection("server=(local)\\SQLEXPRESS;database=master; Integrated Security = SSPI");       //Establece conexion con la BBDD
        SqlCommand comandosql = new SqlCommand();

        public Form_eliminar_usuario()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                MessageBox.Show("Introduca el nombrea a borrar");
            }
            else
            {
                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM usuarios_admin";

                SqlDataReader midatareader = comandosql.ExecuteReader();

                int contador = 0;

                while (midatareader.Read())
                {
                    if (textBox1.Text == midatareader.GetString(0).Trim())
                    {
                        contador = 1;
                        break;
                    }
                }

                midatareader.Close();
                conexion.Close();

                conexion.Open();
                comandosql.Connection = conexion;
                comandosql.CommandText = "Select * FROM usuarios";

                midatareader = comandosql.ExecuteReader();

                while (midatareader.Read())
                {
                    if (textBox1.Text == midatareader.GetString(0).Trim())
                    {
                        contador = 2;
                        break;
                    }
                }

                midatareader.Close();
                conexion.Close();

                if(contador == 1)
                {
                    SqlTransaction mitransaccion;       //Crea una transaccion

                    conexion.Open();        //Abre la conexion con la BBDD

                    mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                    comandosql.Connection = conexion;
                    comandosql.Transaction = mitransaccion;
                    comandosql.CommandText = "DELETE FROM usuarios_admin WHERE nombre='" + textBox1.Text + "');";  //Inroduce el comando

                    try
                    {
                        comandosql.ExecuteNonQuery();   //Ejecuta
                        mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                        MessageBox.Show("Usuario eliminado con exito");
                        DialogResult = DialogResult.OK;
                    }
                    catch
                    {
                        mitransaccion.Rollback(); //Si hay error se eliminará lo realizado
                        MessageBox.Show("Error al modificar los datos a la BBDD");
                    }

                    conexion.Close();
                }
                else if(contador == 2)
                {
                    SqlTransaction mitransaccion;       //Crea una transaccion

                    conexion.Open();        //Abre la conexion con la BBDD

                    mitransaccion = conexion.BeginTransaction();        //Comienza la transaccion
                    comandosql.Connection = conexion;
                    comandosql.Transaction = mitransaccion;
                    comandosql.CommandText = "DELETE FROM usuarios WHERE nombre='" + textBox1.Text + "';";  //Inroduce el comando

                    try
                    {
                        comandosql.ExecuteNonQuery();   //Ejecuta
                        mitransaccion.Commit();         //Si todo va bien ocurre lo siguiente, importante utilizar commit

                        MessageBox.Show("Usuario eliminado con exito");
                        DialogResult = DialogResult.OK;
                    }
                    catch
                    {
                        mitransaccion.Rollback(); //Si hay error se eliminará lo realizado
                        MessageBox.Show("Error al modificar los datos a la BBDD");
                    }

                    conexion.Close();
                }
                else
                {
                    MessageBox.Show("El usuario no exite");
                }
            }
        }
    }
}
