﻿
namespace PF_2106
{
    partial class Form_inicio
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_inicio));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_registrarse = new System.Windows.Forms.Label();
            this.label_contraseña_cambiar = new System.Windows.Forms.Label();
            this.button_salir = new System.Windows.Forms.Button();
            this.button_entrar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_contraseña = new System.Windows.Forms.TextBox();
            this.textBox_nombre = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label_registrarse);
            this.panel1.Controls.Add(this.label_contraseña_cambiar);
            this.panel1.Controls.Add(this.button_salir);
            this.panel1.Controls.Add(this.button_entrar);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox_contraseña);
            this.panel1.Controls.Add(this.textBox_nombre);
            this.panel1.Location = new System.Drawing.Point(187, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 291);
            this.panel1.TabIndex = 0;
            // 
            // label_registrarse
            // 
            this.label_registrarse.AutoSize = true;
            this.label_registrarse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_registrarse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label_registrarse.Location = new System.Drawing.Point(305, 177);
            this.label_registrarse.Name = "label_registrarse";
            this.label_registrarse.Size = new System.Drawing.Size(81, 17);
            this.label_registrarse.TabIndex = 8;
            this.label_registrarse.Text = "Registrarse";
            this.label_registrarse.Click += new System.EventHandler(this.label4_Click);
            // 
            // label_contraseña_cambiar
            // 
            this.label_contraseña_cambiar.AutoSize = true;
            this.label_contraseña_cambiar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_contraseña_cambiar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label_contraseña_cambiar.Location = new System.Drawing.Point(23, 177);
            this.label_contraseña_cambiar.Name = "label_contraseña_cambiar";
            this.label_contraseña_cambiar.Size = new System.Drawing.Size(167, 17);
            this.label_contraseña_cambiar.TabIndex = 7;
            this.label_contraseña_cambiar.Text = "¿Cambiar tu contraseña?";
            this.label_contraseña_cambiar.Click += new System.EventHandler(this.label_contraseña_olvidada_Click);
            // 
            // button_salir
            // 
            this.button_salir.Location = new System.Drawing.Point(311, 231);
            this.button_salir.Name = "button_salir";
            this.button_salir.Size = new System.Drawing.Size(75, 23);
            this.button_salir.TabIndex = 6;
            this.button_salir.Text = "Salir";
            this.button_salir.UseVisualStyleBackColor = true;
            this.button_salir.Click += new System.EventHandler(this.button_salir_Click);
            // 
            // button_entrar
            // 
            this.button_entrar.Location = new System.Drawing.Point(26, 231);
            this.button_entrar.Name = "button_entrar";
            this.button_entrar.Size = new System.Drawing.Size(75, 23);
            this.button_entrar.TabIndex = 5;
            this.button_entrar.Text = "Entrar";
            this.button_entrar.UseVisualStyleBackColor = true;
            this.button_entrar.Click += new System.EventHandler(this.button_entrar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(134, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Inicio de sesión";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Contraseña:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre de usuario:";
            // 
            // textBox_contraseña
            // 
            this.textBox_contraseña.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_contraseña.Location = new System.Drawing.Point(26, 145);
            this.textBox_contraseña.Name = "textBox_contraseña";
            this.textBox_contraseña.Size = new System.Drawing.Size(360, 22);
            this.textBox_contraseña.TabIndex = 1;
            // 
            // textBox_nombre
            // 
            this.textBox_nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_nombre.Location = new System.Drawing.Point(26, 88);
            this.textBox_nombre.Name = "textBox_nombre";
            this.textBox_nombre.Size = new System.Drawing.Size(360, 22);
            this.textBox_nombre.TabIndex = 0;
            // 
            // Form_inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Form_inicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tienda de Golosinas";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_salir;
        private System.Windows.Forms.Button button_entrar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_contraseña;
        private System.Windows.Forms.TextBox textBox_nombre;
        private System.Windows.Forms.Label label_registrarse;
        private System.Windows.Forms.Label label_contraseña_cambiar;
    }
}

